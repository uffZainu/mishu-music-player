package com.mishu.musicplayer

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.media.audiofx.Equalizer
import android.os.Bundle
import android.content.SharedPreferences
import android.os.IBinder
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class EqualizerActivity : AppCompatActivity() {
    private var eq: Equalizer? = null
    private lateinit var prefs: SharedPreferences
    private var serviceBound = false
    private var musicService: MusicService? = null

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val local = binder as MusicService.LocalBinder
            musicService = local.getService()
            serviceBound = true
            setupEqualizer()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            serviceBound = false
            musicService = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = getSharedPreferences("mishu_prefs", Context.MODE_PRIVATE)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_equalizer)
        // bind to service to get audio session id
        bindService(android.content.Intent(this, MusicService::class.java), conn, Context.BIND_AUTO_CREATE)
    }

    override fun onDestroy() {
        // save preset
        try {
            val editor = prefs.edit()
            eq?.let {
                val numBands = it.numberOfBands
                val sb = StringBuilder()
                for (i in 0 until numBands) {
                    sb.append(it.getBandLevel(i.toShort()))
                    if (i < numBands-1) sb.append(",")
                }
                editor.putString("last_eq", sb.toString()).apply()
            }
        } catch(e: Exception) {}
 {
        super.onDestroy()
        eq?.release()
        if (serviceBound) {
            unbindService(conn)
            serviceBound = false
        }
    }

    private fun setupEqualizer() {
        val session = musicService?.getAudioSessionId() ?: 0
        if (session == 0) {
            (findViewById<TextView>(R.id.tvInfo)).text = "Start playback first to enable Equalizer."
            return
        }
        try {
            eq?.release()
            eq = Equalizer(0, session)
            eq?.enabled = true
            val numBands = eq?.numberOfBands ?: 0
            val bandLevelRange = eq?.bandLevelRange
            val minLevel = bandLevelRange?.get(0) ?: 0
            val maxLevel = bandLevelRange?.get(1) ?: 0

            val container = findViewById<LinearLayout>(R.id.eqContainer)
            // Remove old views if any
            container.removeViews(1, container.childCount - 1.coerceAtLeast(1))
            for (i in 0 until numBands) {
                val centerFreq = eq!!.getCenterFreq(i.toShort()) / 1000
                val tv = TextView(this)
                tv.text = "${centerFreq} Hz"
                container.addView(tv)

                val sb = SeekBar(this)
                sb.max = maxLevel - minLevel
                val current = eq!!.getBandLevel(i.toShort()) - minLevel
                sb.progress = current
                val idx = i.toShort()
                sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        val level = (progress + minLevel).toShort()
                        eq?.setBandLevel(idx, level)
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
                val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                sb.layoutParams = params
                container.addView(sb)
            }
        } catch (e: Exception) {
            findViewById<TextView>(R.id.tvInfo).text = "Equalizer not available on this device."
        }
    }
}