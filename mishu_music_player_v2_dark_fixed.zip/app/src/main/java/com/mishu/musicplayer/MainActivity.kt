package com.mishu.musicplayer

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Button
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var listView: ListView
    private lateinit var btnPlay: Button
    private lateinit var btnNext: Button
    private lateinit var btnPrev: Button
    private lateinit var btnEQ: Button
    private lateinit var textTitle: TextView
    private lateinit var seekBar: SeekBar

    private var tracks = mutableListOf<Pair<String, Uri>>()
    private var currentIndex = -1

    private val requestPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        loadTracks()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listView = findViewById(R.id.listView)
        btnPlay = findViewById(R.id.btnPlay)
        btnNext = findViewById(R.id.btnNext)
        btnPrev = findViewById(R.id.btnPrev)
        btnEQ = findViewById(R.id.btnEQ)
        textTitle = findViewById(R.id.textTitle)
        seekBar = findViewById(R.id.seekBar)

        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        requestPermission.launch(perms.toTypedArray())

        listView.setOnItemClickListener { _, _, position, _ ->
            playIndex(position)
        }

        btnPlay.setOnClickListener {
            if (currentIndex == -1 && tracks.isNotEmpty()) playIndex(0)
            else {
                val intent = Intent(this, MusicService::class.java)
                intent.action = MusicService.ACTION_TOGGLE
                startService(intent)
            }
        }
        btnNext.setOnClickListener {
            val intent = Intent(this, MusicService::class.java)
            intent.action = MusicService.ACTION_NEXT
            startService(intent)
        }
        btnPrev.setOnClickListener {
            val intent = Intent(this, MusicService::class.java)
            intent.action = MusicService.ACTION_PREV
            startService(intent)
        }

        btnEQ.setOnClickListener {
            val intent = Intent(this, EqualizerActivity::class.java)
            startActivity(intent)
        }

        startService(Intent(this, MusicService::class.java))
    }

    private fun loadTracks() {
        tracks.clear()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE
        )
        val selection = MediaStore.Audio.Media.IS_MUSIC + "!= 0"
        val cursor = contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection, selection, null,
            MediaStore.Audio.Media.TITLE + " ASC"
        )
        cursor?.use {
            val idIdx = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleIdx = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            while (it.moveToNext()) {
                val id = it.getLong(idIdx)
                val title = it.getString(titleIdx)
                val uri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())
                tracks.add(title to uri)
            }
        }
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, tracks.map { it.first })
        listView.adapter = adapter
    }

    private fun playIndex(index: Int) {
        if (index < 0 || index >= tracks.size) return
        currentIndex = index
        val uri = tracks[index].second
        val intent = Intent(this, MusicService::class.java)
        intent.action = MusicService.ACTION_PLAY
        intent.putExtra(MusicService.EXTRA_URI, uri.toString())
        startService(intent)
        textTitle.text = tracks[index].first
        btnPlay.text = "Pause"
    }
}