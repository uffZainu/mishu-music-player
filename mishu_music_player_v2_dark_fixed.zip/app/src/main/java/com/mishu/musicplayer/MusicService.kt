
package com.mishu.musicplayer

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.media.app.NotificationCompat.MediaStyle
import android.support.v4.media.session.MediaSessionCompat
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import android.content.Context
import android.media.audiofx.Equalizer
import android.content.IntentFilter
import android.os.Build
import androidx.core.app.NotificationManagerCompat

class MusicService : Service() {
    companion object {
        const val ACTION_PLAY = "ACTION_PLAY"
        const val ACTION_TOGGLE = "ACTION_TOGGLE"
        const val ACTION_NEXT = "ACTION_NEXT"
        const val ACTION_PREV = "ACTION_PREV"
        const val EXTRA_URI = "EXTRA_URI"
        const val CHANNEL_ID = "mishu_music_channel"
        const val NOTIF_ID = 1001
    }

    private val binder = LocalBinder()
    private var player: ExoPlayer? = null
    private var mediaSession: MediaSessionCompat? = null
    private var equalizer: Equalizer? = null

    inner class LocalBinder : Binder() {
        fun getService(): MusicService = this@MusicService
    }

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this).build()
        mediaSession = MediaSessionCompat(this, "MishuMusicSession")
        player?.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                showNotification()
            }
        })
    }

    override fun onBind(intent: Intent?): IBinder? {
        return binder
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.action?.let { action ->
            when(action) {
                ACTION_PLAY -> {
                    val uriStr = intent.getStringExtra(EXTRA_URI) ?: return@let
                    val mediaItem = MediaItem.fromUri(uriStr)
                    player?.setMediaItem(mediaItem)
                    player?.prepare()
                    player?.play()
                    showNotification()
                }
                ACTION_TOGGLE -> {
                    player?.let {
                        if (it.isPlaying) it.pause() else it.play()
                    }
                }
            }
        }
        return START_STICKY
    }

    fun getAudioSessionId(): Int {
        return player?.audioSessionId ?: 0
    }

    private fun showNotification() {
        val playIntent = Intent(this, MusicService::class.java).apply { action = ACTION_TOGGLE }
        val pPlay = PendingIntent.getService(this, 0, playIntent, PendingIntent.FLAG_IMMUTABLE)
        val contentIntent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Mishu Music Player")
            .setContentText(if (player?.isPlaying == true) "Playing" else "Paused")
            .setContentIntent(contentIntent)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(android.R.drawable.ic_media_previous, "Prev", null)
            .addAction(android.R.drawable.ic_media_play, "Play", pPlay)
            .addAction(android.R.drawable.ic_media_next, "Next", null)
            .setStyle(MediaStyle().setShowActionsInCompactView(1))
            .setPriority(NotificationCompat.PRIORITY_LOW)

        val notif = builder.build()
        startForeground(NOTIF_ID, notif)
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        mediaSession?.release()
        equalizer?.release()
    }
}
