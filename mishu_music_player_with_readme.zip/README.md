# 🎵 Mishu Music Player
**Feel the Rhythm**

A clean, ad-free music player for Android 10+.  
Built with ExoPlayer + Equalizer + Material Design 3.

## ✨ Features
- 🎚️ Equalizer with presets
- 🔊 Lock-screen & notification controls
- 🌗 Light/Dark themes
- 🚀 Fast & ad-free
- 🎶 Modern splash screen with gradient animation

## 🛠️ Tech Stack
Kotlin | ExoPlayer | Material Design | MVVM | Jetpack

## 📱 Requirements
- **Minimum Android:** 10 (API 29)
- **Package name:** `com.mishu.musicplayer`

## 🧩 How to Build
1. Open the project in Android Studio.
2. Let Gradle sync complete.
3. Run the app on your device or emulator.
4. To build Play Store version: `Build → Generate Signed Bundle / APK`.

## 🌐 GitHub Repository
[https://github.com/uffZainu/mishu-music-player](https://github.com/uffZainu/mishu-music-player)

## 🖼️ Screenshots
*(Add later after testing on device)*

## 🪪 License
MIT License © 2025 Mishu Music Player Team
